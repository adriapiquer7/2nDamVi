package patroDao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;

import modelDades.Estat;
import modelDades.Impostor;
import modelDades.Nau;
import modelDades.Personatge;
import modelDades.Tasca;
import modelDades.Tripulant;

public class PersonatgeDao extends GenericDao<Personatge, Integer> implements IPersonatgeDao {

	@Override
	public Personatge[] eliminar(int idImpostor, int idVictima) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			eliminar(session, idImpostor, idVictima);
			session.getTransaction().commit();
		} catch (RuntimeException e) {
			handleException(session, e);
		}
		// Un cop persistits els canvis, tornem a consultar la BD reutilitzant get()
		return new Personatge[] { get(idImpostor), get(idVictima) };
	}

	private void eliminar(Session session, int idImpostor, int idVictima) {
		if (idImpostor == idVictima) {
			System.out.println("\tUn Personatge no pot eliminar-se a si mateix");
			return;
		}
		Personatge b1 = session.get(Impostor.class, idImpostor);
		Personatge b2 = session.get(Tripulant.class, idVictima);
		if(b1.getEstat().equals(Estat.VIU)&&b2.getEstat().equals(Estat.VIU))
		{
			if(b1 instanceof Impostor && b2 instanceof Tripulant) {
				if(b1.getNau()==b2.getNau()) {
					b2.setEstat(Estat.FANTASMA);
					Tasca tascaActiva = b2.getTascaActiva();
					//tascaActiva.setCompletadors(tascaActiva.getCompletadors().remove(b2));
					b2.setTascaActiva(null);
					b1.setPunts(b1.getPunts()+10);
					if(b1.getNau().isVentilacions()) {
						b1.setSospita(b1.getSospita()+10);
					}
					else {
						b1.setSospita(b1.getSospita()+20);
					}
					if(b1.getSospita()>=100) {
						System.out.println(b1.getNom()+" ha estat vist eliminant "+b2.getNom());
					}
					return;
				}
				else {
					System.out.println("Els personatges no estan a la mateixa nau");
					return;
				}
			}
			else {
				System.out.println("Algun jugador no te el rol ben assignat");
				return;
			}
		}
		else {
			System.out.println("algun jugador no esta viu");
			return;
		}
		
	}

	@Override
	public Personatge completarTasca(Personatge personatge) {
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			completarTasca(session, personatge);
			session.getTransaction().commit();
		} catch (RuntimeException e) {
			handleException(session, e);
		}
		// Un cop persistits els canvis, tornem a consultar la BD reutilitzant get()
		return null;
	}

	private void completarTasca(Session session, Personatge per) {
		if(per.getTascaActiva()==null||per.getEstat().equals(Estat.EXPULSAT)) {
			System.out.println("El personatge no te tasques o esta expulsat");
			return;
		}
		else {
			Tasca t = per.getTascaActiva();
			//t.setActius(t.getActius().remove(per));
			//t.setCompletadors(t.getCompletadors().add(per));

		}
		
	}

	@Override
	public List<Personatge> reunioEmergencia(int idNau) {
		List<Personatge> ids = new ArrayList<>();
		Session session = sessionFactory.getCurrentSession();
		try {
			session.beginTransaction();
			ids = reunioEmergencia(session, idNau);
			session.getTransaction().commit();
		} catch (RuntimeException e) {
			handleException(session, e);
			ids = new ArrayList<>(); // rollback: no s'ha tractat cap brawler
		}
		// Els brawlers tractats, consultats de nou a la BD reutilitzant get()
		List<Personatge> tractats = new ArrayList<>();
		for (Personatge p : ids) {
			tractats.add(get(p.getId()));
		}
		return tractats;
	}

	private List<Personatge> reunioEmergencia(Session session, int idNau) {
		Nau n = session.get(Nau.class, idNau);
		Personatge expulsat = null;
		boolean empat = false;
		List<Personatge> reunio = n.getPersonatges();
		for (Personatge p : reunio) {
			if(p.getEstat().equals(Estat.FANTASMA)||p.getEstat().equals(Estat.EXPULSAT)) {
				reunio.remove(p);
			}
		}
		for (Personatge p : reunio) {
			double sospita = 0;
			if(p.getSospita()>sospita) {
				expulsat=p;
			}
			if(p.getSospita()==sospita) {
				empat = true;
			}
		}
		if(empat) {
			System.out.println("Ningu ha eswtat expulsat, (empat)");
		}
		else {
			expulsat.setEstat(Estat.EXPULSAT);
			expulsat.setTascaActiva(null);
			if(expulsat instanceof Impostor) {
				System.out.println(expulsat.getNom()+" era impostor");
			}
			else {
				System.out.println(expulsat.getNom()+" no era impostor");
			}
			reunio.remove(expulsat);
			for (Personatge p : reunio) {
				p.setSospita(p.getSospita()/2);
			}
			int numImpostors = 0;
			int numTripulants =0;
			for (Personatge p : reunio) {
				if(p instanceof Impostor) {
					numImpostors++;
				}
				else {
					numTripulants++;
				}
			}
			if(numImpostors>=numTripulants) {
				System.out.println("VICTORIA DEL IMPOSTORS");
			}
			else if(numImpostors==0) {
				System.out.println("VICTORIA DEL TRIPULANTS");
			}
		}
		return reunio;
	}

}
