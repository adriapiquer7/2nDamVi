package patroDao;

import java.util.List;

import modelDades.Personatge;

public interface IPersonatgeDao {
	Personatge[] eliminar(int idImpostor, int idVictima);
	
	Personatge completarTasca(Personatge personatge);
	
	List<Personatge> reunioEmergencia(int idNau);
}
