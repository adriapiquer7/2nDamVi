package patroDao;

import static patroDao.Correccio.comprova;
import static patroDao.Correccio.comprovaNoCanvi;
import static patroDao.Correccio.crida;
import static patroDao.Correccio.executa;
import static patroDao.Correccio.haImpres;
import static patroDao.Correccio.item;
import static patroDao.Correccio.itemManual;
import static patroDao.Correccio.titol;
import static patroDao.DadesProva.estat;
import static patroDao.DadesProva.id;
import static patroDao.DadesProva.idNau;
import static patroDao.DadesProva.numActius;
import static patroDao.DadesProva.numCompletades;
import static patroDao.DadesProva.numCompletadors;
import static patroDao.DadesProva.punts;
import static patroDao.DadesProva.sospita;
import static patroDao.DadesProva.tascaActiva;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Arrays;
import java.util.List;

import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import modelDades.Color;
import modelDades.Estat;
import modelDades.Impostor;
import modelDades.Nau;
import modelDades.Personatge;
import modelDades.Tasca;
import modelDades.Tripulant;

/**
 * =====================================================================================
 *  MAIN D'AUTOCORRECCIÓ - Examen Hibernate Among Us. NO L'HEU DE MODIFICAR.
 * =====================================================================================
 *
 * Com fer-lo servir:
 *  1. Perquè compili, heu de tenir el model complet (constructors, getters i setters de l'enunciat)
 *     i la classe PersonatgeDao amb els 3 mètodes. Si encara no heu fet algun mètode,
 *     creeu-lo buit (return null;) i el Main el marcarà com a ERROR.
 *  2. Executeu-lo tantes vegades com vulgueu: abans de cada prova es reinicien les dades
 *     (vegeu DadesProva, on hi ha la taula amb totes les dades inicials).
 *  3. Cada comprovació mostra [OK] o [ERROR] amb el valor esperat i l'obtingut.
 *     Al codi, el comentari "Hauria de tornar" us diu què s'espera abans d'executar-ho.
 *  4. Al final hi ha un SIMULACRE DE PUNTUACIÓ aproximat: no és la nota de l'examen.
 */
public class Main {

	static PersonatgeDao pDao;

	public static void main(String[] args) {
		rubrica();
		try {
			pDao = new PersonatgeDao();
			DadesProva.reiniciar();
		} catch (Throwable e) {
			System.out.println("No s'ha pogut crear el DAO o carregar les dades de prova:");
			e.printStackTrace(System.out);
			System.out.println("Reviseu hibernate.cfg.xml, SessionManager i les anotacions del model.");
		}

		if (pDao != null) {
			provesModel();
			provesHerencia();
			provesToString();
			provesEstructuraDao();
			provesEliminar();
			provesCompletarTasca();
			provesReunioEmergencia();
		}

		Correccio.simulacre();
		try {
			SessionManager.getSessionFactory().close();
		} catch (Throwable e) {
			// res
		}
	}

	private static void rubrica() {
		itemManual(1, "Excepcions, transaccions, commits i rollbacks", 1);
		item(2, "Classes correctes (anotacions, constructors i setters)", 1);
		item(3, "Herència: Personatge abstracta i SINGLE_TABLE", 0.5);
		item(4, "Interfícies i classes DAO", 1);
		item(5, "toString des de Personatge (amb el rol) sense recursivitat", 0.5);
		item(6, "Reducció de sospita en assignar una tasca activa", 0.5);
		item(7, "eliminar: valida rols, estat i nau", 0.5);
		item(8, "eliminar: efectes sobre víctima i impostor", 0.5);
		item(9, "eliminar: retorna l'array actualitzat", 0.5);
		item(10, "completarTasca: tasca activa i completades", 0.5);
		item(11, "completarTasca: llistes de la Tasca", 0.5);
		item(12, "completarTasca: Tripulant/Impostor i casos no vàlids", 0.5);
		item(13, "completarTasca: retorna el personatge actualitzat", 0.5);
		item(14, "reunioEmergencia: vius, expulsat i empats", 0.5);
		item(15, "reunioEmergencia: rol, sospita de la resta i victòria", 0.5);
		item(16, "reunioEmergencia: retorna la llista actualitzada", 1);
	}

	/* =====================================================================
	 * MODEL: constructors, setters amb control i relacions als dos costats
	 * ===================================================================== */

	private static void provesModel() {
		titol("MODEL: constructors i setters");

		// Les dades de prova s'han carregat amb els vostres setters
		// Hauria de tornar: 11 personatges a la BD
		comprova(2, "Hi ha 11 personatges a la BD", 11L, () -> DadesProva.numPersonatges());
		// Hauria de tornar: The Skeld té 5 personatges, Cables té 2 actius (Lia i Iu) i 1 completador (Max)
		comprova(2, "The Skeld té 5 personatges a la BD", 5L, () -> DadesProva.numPersonatgesNau("The Skeld"));
		comprova(2, "Cables té 2 personatges actius a la BD", 2L, () -> numActius("Cables"));
		comprova(2, "Cables té 1 completador a la BD", 1L, () -> numCompletadors("Cables"));

		// Constructor: nom i color. Hauria de tornar: VIU, sospita 0 i 0 punts
		comprova(2, "new Tripulant(nom, color) comença VIU", Estat.VIU, () -> new Tripulant("Prova", Color.BLAU).getEstat());
		comprova(2, "new Impostor(nom, color) comença amb sospita 0", 0.0,
				() -> new Impostor("Prova", Color.NEGRE).getSospita());
		comprova(2, "new Tripulant(nom, color) comença amb 0 punts", 0, () -> new Tripulant("Prova", Color.BLAU).getPunts());

		// Límits. Hauria de tornar: sospita 100 (màxim), sospita 0 (mínim) i punts 0 (no negatius)
		comprova(2, "setSospita(150) deixa 100", 100.0, () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			p.setSospita(150);
			return p.getSospita();
		});
		comprova(2, "setSospita(-5) deixa 0", 0.0, () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			p.setSospita(-5);
			return p.getSospita();
		});
		comprova(2, "setPunts(-3) deixa 0", 0, () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			p.setPunts(-3);
			return p.getPunts();
		});

		// setNau: el personatge també apareix a la llista de la nau
		comprova(2, "setNau afegeix el personatge a nau.getPersonatges()", () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			Nau n = new Nau("NauProva", 5, false);
			p.setNau(n);
			return n.getPersonatges().contains(p);
		});

		// Una tasca completada no pot ser la tasca activa. Hauria de tornar: tasca activa null
		comprova(2, "No es pot posar com a activa una tasca ja completada", () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			Tasca t = new Tasca("TascaProva", "Sala", 10, 5);
			p.afegirTascaCompletada(t);
			p.setTascaActiva(t);
			return p.getTascaActiva() == null;
		});

		// Completar la tasca activa: deixa de ser activa, surt dels actius i entra als completadors
		comprova(2, "afegirTascaCompletada de la tasca activa la treu d'activa", () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			Tasca t = new Tasca("TascaProva", "Sala", 10, 5);
			p.setTascaActiva(t);
			p.afegirTascaCompletada(t);
			return p.getTascaActiva() == null && !t.getActius().contains(p) && t.getCompletadors().contains(p)
					&& p.getTasquesCompletades().contains(t);
		});

		titol("MODEL: reducció de sospita");
		// Hauria de tornar: 20 - 15 = 5 i el personatge als actius de la tasca
		comprova(6, "setTascaActiva redueix la sospita (20 - 15)", 5.0, () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			p.setSospita(20);
			p.setTascaActiva(new Tasca("TascaProva", "Sala", 10, 15));
			return p.getSospita();
		});
		comprova(6, "setTascaActiva afegeix el personatge als actius de la tasca", () -> {
			Personatge p = new Tripulant("Prova", Color.BLAU);
			Tasca t = new Tasca("TascaProva", "Sala", 10, 15);
			p.setTascaActiva(t);
			return t.getActius().contains(p);
		});
		// Hauria de tornar: 0 (la sospita no baixa de zero: 10 - 15)
		comprova(6, "La sospita no queda en negatiu (10 - 15)", 0.0, () -> {
			Personatge p = new Impostor("Prova", Color.NEGRE);
			p.setSospita(10);
			p.setTascaActiva(new Tasca("TascaProva", "Sala", 10, 15));
			return p.getSospita();
		});
	}

	/* =====================================================================
	 * HERÈNCIA
	 * ===================================================================== */

	private static void provesHerencia() {
		titol("HERÈNCIA");
		comprova(3, "Personatge és abstracta", () -> Modifier.isAbstract(Personatge.class.getModifiers()));
		comprova(3, "Tripulant i Impostor hereten de Personatge",
				() -> Tripulant.class.getSuperclass() == Personatge.class
						&& Impostor.class.getSuperclass() == Personatge.class);
		comprova(3, "Estratègia SINGLE_TABLE", InheritanceType.SINGLE_TABLE,
				() -> Personatge.class.getAnnotation(Inheritance.class).strategy());
		comprova(3, "Columna discriminadora anomenada \"rol\"", "rol",
				() -> Personatge.class.getAnnotation(DiscriminatorColumn.class).name());
		comprova(3, "Les subclasses no tenen atributs propis",
				() -> senseAtributs(Tripulant.class) && senseAtributs(Impostor.class));
		comprova(3, "Personatge no té cap atribut de rol (rol, esImpostor...)",
				() -> Arrays.stream(Personatge.class.getDeclaredFields())
						.noneMatch(f -> f.getName().toLowerCase().contains("rol")
								|| f.getName().toLowerCase().contains("impostor")));
	}

	private static boolean senseAtributs(Class<?> classe) {
		return Arrays.stream(classe.getDeclaredFields()).allMatch(f -> Modifier.isStatic(f.getModifiers()));
	}

	/* =====================================================================
	 * toString
	 * ===================================================================== */

	private static void provesToString() {
		titol("toString (personatges retornats pel DAO, fora de la sessió)");
		reiniciar();
		Personatge max = crida(() -> pDao.get(id("Max")));
		String text = crida(() -> max.toString());
		System.out.println("\t" + text);
		Personatge kai = crida(() -> pDao.get(id("Kai")));
		String textKai = crida(() -> kai.toString());
		// Hauria de mostrar: rol, nom, nau, tasca activa i tasques completades
		comprova(5, "toString sense excepcions (LazyInitialization, StackOverflow...)", () -> text != null);
		comprova(5, "Mostra el rol (Tripulant i Impostor)",
				() -> text.contains("Tripulant") && textKai.contains("Impostor"));
		comprova(5, "Mostra la nau (The Skeld)", () -> text.contains("The Skeld"));
		comprova(5, "Mostra la tasca activa (Escut)", () -> text.contains("Escut"));
		comprova(5, "Mostra les tasques completades (Cables)", () -> text.contains("Cables"));
	}

	/* =====================================================================
	 * ESTRUCTURA DEL DAO
	 * ===================================================================== */

	private static void provesEstructuraDao() {
		titol("ESTRUCTURA DEL DAO");
		comprova(4, "IPersonatgeDao és una interfície que hereta de IGenericDao", () -> {
			Class<?> i = Class.forName("patroDao.IPersonatgeDao");
			return i.isInterface() && Arrays.asList(i.getInterfaces()).contains(Class.forName("patroDao.IGenericDao"));
		});
		comprova(4, "PersonatgeDao hereta de GenericDao", "GenericDao",
				() -> PersonatgeDao.class.getSuperclass().getSimpleName());
		comprova(4, "PersonatgeDao implementa IPersonatgeDao", () -> Arrays.asList(PersonatgeDao.class.getInterfaces())
				.contains(Class.forName("patroDao.IPersonatgeDao")));
		comprova(4, "IPersonatgeDao declara els 3 mètodes de l'enunciat", () -> {
			Class<?> i = Class.forName("patroDao.IPersonatgeDao");
			Method eliminar = i.getMethod("eliminar", int.class, int.class);
			Method completar = i.getMethod("completarTasca", Personatge.class);
			Method reunio = i.getMethod("reunioEmergencia", int.class);
			return eliminar.getReturnType() == Personatge[].class && completar.getReturnType() == Personatge.class
					&& List.class.isAssignableFrom(reunio.getReturnType());
		});
		// Penalització de l'enunciat: no es puntua aquí, només s'avisa
		for (String nom : List.of("NauDao", "TascaDao", "TripulantDao", "ImpostorDao")) {
			try {
				Class.forName("patroDao." + nom);
				System.out.println("\t[AVÍS] Existeix " + nom + ": fer DAO per a totes les classes té penalització d'1 punt");
			} catch (ClassNotFoundException e) {
				// correcte: no n'hi ha
			}
		}
	}

	/* =====================================================================
	 * eliminar(int idImpostor, int idVictima)
	 * ===================================================================== */

	private static void provesEliminar() {
		titol("eliminar");

		// A) Kai (Impostor, The Skeld AMB ventilacions, sospita 30) elimina Lia (tasca activa Cables)
		reiniciar();
		Personatge[] r = crida(() -> pDao.eliminar(id("Kai"), id("Lia")));
		// Hauria de tornar: [Kai amb 10 punts i sospita 40 (30 + 10), Lia FANTASMA sense tasca activa]
		boolean funciona = comprova(8, "Lia passa a FANTASMA", Estat.FANTASMA, () -> estat("Lia"));
		comprova(8, "Lia deixa la tasca activa", null, () -> tascaActiva("Lia"));
		comprova(8, "Cables ja només té 1 actiu (Iu)", 1L, () -> numActius("Cables"));
		funciona |= comprova(8, "Kai guanya 10 punts", 10, () -> punts("Kai"));
		comprova(8, "Amb ventilacions la sospita de Kai només puja 10: 30 + 10 = 40", 40.0, () -> sospita("Kai"));
		comprova(9, "Retorna un array de 2 personatges", 2, () -> r.length);
		comprova(9, "El primer és l'impostor (Kai) amb sospita 40 i 10 punts", "Kai 40.0 10",
				() -> r[0].getNom() + " " + r[0].getSospita() + " " + r[0].getPunts());
		comprova(9, "El segon és la víctima (Lia), FANTASMA", "Lia FANTASMA", () -> r[1].getNom() + " " + r[1].getEstat());

		// B) Bru (Impostor, Polus SENSE ventilacions, sospita 85) elimina Pau
		reiniciar();
		executa(() -> pDao.eliminar(id("Bru"), id("Pau")));
		// Hauria de tornar: Bru amb sospita 100 (85 + 20, màxim 100) i imprimir "Bru ha estat vist eliminant Pau!"
		comprova(8, "Sense ventilacions la sospita puja 20 (màxim 100): Bru 100", 100.0, () -> sospita("Bru"));
		comprova(8, "Imprimeix \"Bru ha estat vist eliminant Pau!\"", () -> haImpres("Bru ha estat vist eliminant Pau!"));
		comprova(8, "Pau passa a FANTASMA", Estat.FANTASMA, () -> estat("Pau"));

		// C) Casos no vàlids: no s'ha de fer cap canvi
		reiniciar();
		Personatge[] r2 = crida(() -> pDao.eliminar(id("Lia"), id("Max")));
		// Lia no és impostora. Hauria de tornar: [Lia, Max] sense canvis (Max VIU)
		comprovaNoCanvi(funciona, 7, "Una tripulant (Lia) no pot eliminar: Max continua VIU", Estat.VIU, () -> estat("Max"));
		comprova(9, "En un cas no vàlid retorna els dos personatges sense canvis", "Lia VIU / Max VIU",
				() -> r2[0].getNom() + " " + r2[0].getEstat() + " / " + r2[1].getNom() + " " + r2[1].getEstat());

		reiniciar();
		executa(() -> pDao.eliminar(id("Kai"), id("Bru")));
		comprovaNoCanvi(funciona, 7, "No es pot eliminar un impostor: Bru continua VIU", Estat.VIU, () -> estat("Bru"));

		reiniciar();
		executa(() -> pDao.eliminar(id("Kai"), id("Ona")));
		comprovaNoCanvi(funciona, 7, "Naus diferents (Kai a The Skeld, Ona a Polus): Ona continua VIVA", Estat.VIU,
				() -> estat("Ona"));

		reiniciar();
		executa(() -> pDao.eliminar(id("Kai"), id("Iu")));
		comprovaNoCanvi(funciona, 7, "Iu ja és FANTASMA: Kai no guanya punts", 0, () -> punts("Kai"));

		reiniciar();
		executa(() -> pDao.eliminar(id("Kai"), id("Txell")));
		comprovaNoCanvi(funciona, 7, "Txell està EXPULSADA: Kai no guanya punts", 0, () -> punts("Kai"));
	}

	/* =====================================================================
	 * completarTasca(Personatge personatge)
	 * ===================================================================== */

	private static void provesCompletarTasca() {
		titol("completarTasca");

		// A) Max (Tripulant, 70 punts) completa Escut (40 punts)
		reiniciar();
		Personatge max = crida(() -> completar("Max"));
		// Hauria de tornar: Max amb 110 punts, sense tasca activa i 2 completades; imprimir "Max ha omplert la barra de tasques!"
		boolean funciona = comprova(10, "Max ja no té tasca activa", null, () -> tascaActiva("Max"));
		funciona |= comprova(10, "Max té 2 tasques completades (Cables i Escut)", 2L, () -> numCompletades("Max"));
		comprova(11, "Escut ja no té actius", 0L, () -> numActius("Escut"));
		comprova(11, "Escut té 1 completador (Max)", 1L, () -> numCompletadors("Escut"));
		funciona |= comprova(12, "Tripulant: Max rep els punts de la tasca: 70 + 40 = 110", 110, () -> punts("Max"));
		comprova(12, "Imprimeix \"Max ha omplert la barra de tasques!\"",
				() -> haImpres("Max ha omplert la barra de tasques!"));
		comprova(13, "Retorna Max amb 110 punts i sense tasca activa", "Max 110 null",
				() -> max.getNom() + " " + max.getPunts() + " " + max.getTascaActiva());

		// B) Kai (Impostor, sospita 30) "completa" Combustible
		reiniciar();
		Personatge kai = crida(() -> completar("Kai"));
		// Hauria de tornar: Kai amb 0 punts i sospita 45 (30 + 15)
		comprova(12, "Impostor: la sospita de Kai puja 15: 30 + 15 = 45", 45.0, () -> sospita("Kai"));
		comprovaNoCanvi(funciona, 12, "Impostor: Kai no rep punts", 0, () -> punts("Kai"));
		comprova(10, "Kai ja no té tasca activa", null, () -> tascaActiva("Kai"));
		comprova(11, "Combustible té 1 completador (Kai)", 1L, () -> numCompletadors("Combustible"));
		comprova(13, "Retorna Kai amb sospita 45", 45.0, () -> kai.getSospita());

		// C) Iu és un FANTASMA amb la tasca Cables (30 punts): també pot fer tasques
		reiniciar();
		executa(() -> completar("Iu"));
		// Hauria de tornar: Iu amb 10 + 30 = 40 punts
		comprova(12, "Un fantasma també completa tasques: Iu 10 + 30 = 40", 40, () -> punts("Iu"));

		// D) Casos no vàlids: no s'ha de fer cap canvi
		reiniciar();
		executa(() -> completar("Txell"));
		// Txell està EXPULSADA. Hauria de tornar: Txell sense canvis (tasca activa Asteroides)
		comprovaNoCanvi(funciona, 12, "Txell (EXPULSADA) no pot completar: conserva Asteroides", "Asteroides",
				() -> tascaActiva("Txell"));
		reiniciar();
		executa(() -> completar("Pau"));
		// Pau no té tasca activa. Hauria de tornar: Pau sense canvis (30 punts, 1 completada)
		comprovaNoCanvi(funciona, 12, "Pau (sense tasca activa) no canvia: 30 punts", 30, () -> punts("Pau"));
	}

	// El mètode rep un Personatge: el demanem al DAO i el passem
	private static Personatge completar(String nom) {
		Personatge p = pDao.get(id(nom));
		return pDao.completarTasca(p);
	}

	/* =====================================================================
	 * reunioEmergencia(int idNau)
	 * ===================================================================== */

	private static void provesReunioEmergencia() {
		titol("reunioEmergencia");

		// A) The Skeld: vius Kai (30), Lia (10) i Max (20). Iu és FANTASMA i Txell EXPULSADA: no hi participen
		//    Kai té la màxima -> EXPULSAT ("Kai era un impostor"). La resta de vius: sospita a la meitat
		//    No queda cap impostor viu -> "VICTÒRIA DELS TRIPULANTS"
		reiniciar();
		List<Personatge> llista = crida(() -> pDao.reunioEmergencia(idNau("The Skeld")));
		// Hauria de tornar els 5 personatges de The Skeld: Kai EXPULSAT, Lia sospita 5 i Max sospita 10
		boolean funciona = comprova(14, "Kai (més sospita) és EXPULSAT", Estat.EXPULSAT, () -> estat("Kai"));
		comprova(14, "Kai deixa la tasca activa", null, () -> tascaActiva("Kai"));
		comprova(15, "Imprimeix \"Kai era un impostor\"", () -> haImpres("Kai era un impostor"));
		funciona |= comprova(15, "Lia redueix la sospita a la meitat: 10 -> 5", 5.0, () -> sospita("Lia"));
		comprova(15, "Max redueix la sospita a la meitat: 20 -> 10", 10.0, () -> sospita("Max"));
		comprovaNoCanvi(funciona, 14, "Txell (EXPULSADA) no participa: sospita 50", 50.0, () -> sospita("Txell"));
		comprova(15, "Imprimeix \"VICTÒRIA DELS TRIPULANTS\"", () -> haImpres("VICTÒRIA DELS TRIPULANTS"));
		comprova(16, "Retorna els 5 personatges de The Skeld", 5, () -> llista.size());
		comprova(16, "A la llista retornada, Kai és EXPULSAT", Estat.EXPULSAT, () -> buscar(llista, "Kai").getEstat());
		comprova(16, "A la llista retornada, Lia té sospita 5", 5.0, () -> buscar(llista, "Lia").getSospita());
		comprova(16, "A la llista retornada hi ha Iu i Txell (tots els de la nau)",
				() -> buscarOpcional(llista, "Iu") != null && buscarOpcional(llista, "Txell") != null);

		// B) Polus: Bru (85) i Ona (85) empaten amb la màxima -> ningú és expulsat
		//    Tots els vius redueixen la sospita a la meitat. Queden 1 impostor i 2 tripulants: sense victòria
		reiniciar();
		executa(() -> pDao.reunioEmergencia(idNau("Polus")));
		// Hauria de tornar: Bru i Ona VIUS amb 42.5, Pau amb 20, i imprimir "Ningú ha estat expulsat (empat)"
		comprova(14, "Imprimeix \"Ningú ha estat expulsat (empat)\"", () -> haImpres("Ningú ha estat expulsat (empat)"));
		comprovaNoCanvi(funciona, 14, "Empat: Bru i Ona continuen VIUS", "VIU VIU", () -> estat("Bru") + " " + estat("Ona"));
		comprova(15, "Empat: tots els vius a la meitat (Bru 42.5, Pau 20.0, Ona 42.5)", "42.5 20.0 42.5",
				() -> sospita("Bru") + " " + sospita("Pau") + " " + sospita("Ona"));
		comprovaNoCanvi(funciona, 15, "1 impostor i 2 tripulants vius: no imprimeix cap VICTÒRIA",
				() -> !haImpres("VICTÒRIA"));

		// C) MIRA HQ: Jan (60) té la màxima -> EXPULSAT ("Jan no era un impostor")
		//    Queden Zoe (impostora) i Abril (tripulant): 1 >= 1 -> "VICTÒRIA DELS IMPOSTORS"
		reiniciar();
		List<Personatge> llista3 = crida(() -> pDao.reunioEmergencia(idNau("MIRA HQ")));
		// Hauria de tornar els 3 personatges: Jan EXPULSAT, Zoe sospita 5 i Abril sospita 10
		comprova(14, "Jan (més sospita) és EXPULSAT", Estat.EXPULSAT, () -> estat("Jan"));
		comprova(15, "Imprimeix \"Jan no era un impostor\"", () -> haImpres("Jan no era un impostor"));
		comprova(15, "Zoe i Abril a la meitat (5.0 i 10.0)", "5.0 10.0", () -> sospita("Zoe") + " " + sospita("Abril"));
		comprova(15, "Imprimeix \"VICTÒRIA DELS IMPOSTORS\"", () -> haImpres("VICTÒRIA DELS IMPOSTORS"));
		comprova(16, "Retorna els 3 personatges de MIRA HQ", 3, () -> llista3.size());
		comprova(16, "A la llista retornada, Jan és EXPULSAT", Estat.EXPULSAT, () -> buscar(llista3, "Jan").getEstat());
	}

	/* =====================================================================
	 * Auxiliars
	 * ===================================================================== */

	// Torna a crear les dades de prova. Si falla (p. ex. per un error als setters), ho mostra i continua
	private static void reiniciar() {
		executa(DadesProva::reiniciar);
	}

	private static Personatge buscar(List<Personatge> llista, String nom) {
		Personatge p = buscarOpcional(llista, nom);
		if (p == null) {
			throw new IllegalStateException(nom + " no és a la llista retornada");
		}
		return p;
	}

	private static Personatge buscarOpcional(List<Personatge> llista, String nom) {
		for (Personatge p : llista) {
			if (p != null && nom.equals(p.getNom())) {
				return p;
			}
		}
		return null;
	}
}
