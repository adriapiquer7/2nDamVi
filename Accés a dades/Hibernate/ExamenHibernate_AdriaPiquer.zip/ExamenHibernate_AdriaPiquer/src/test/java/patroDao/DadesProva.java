package patroDao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import modelDades.Color;
import modelDades.Estat;
import modelDades.Impostor;
import modelDades.Nau;
import modelDades.Personatge;
import modelDades.Tasca;
import modelDades.Tripulant;

/*
 * =====================================================================================
 *  DADES DE PROVA. NO L'HEU DE MODIFICAR.
 * =====================================================================================
 * - reiniciar(): esborra totes les dades i torna a crear les de la taula de sota.
 *   El Main el crida abans de provar cada funció: així un error en una funció
 *   no afecta les proves de les altres.
 * - La resta de mètodes consulten la BD DIRECTAMENT (sense passar pel vostre DAO)
 *   per comprovar què ha quedat desat de veritat.
 *
 * Fa servir els vostres constructors i setters: Nau(nom, numSales, ventilacions),
 * Tasca(nom, sala, punts, reduccioSospita), Tripulant(nom, color), Impostor(nom, color),
 * setNau, setTascaActiva, afegirTascaCompletada, setEstat, setSospita i setPunts.
 *
 * DADES (després de reiniciar):
 *
 *   Naus:    The Skeld (14 sales, AMB ventilacions), Polus (15, SENSE), MIRA HQ (11, AMB)
 *
 *   Tasques: Cables (Electricitat, 30 punts, redueix 10 de sospita)
 *            Escut (Escuts, 40, 15)     Combustible (Motors, 20, 5)
 *            Asteroides (Armes, 60, 20) Reactor (Reactor, 50, 10)
 *
 *   Nau        Nom    Rol        Estat     Sospita  Punts  Tasca activa  Completades
 *   The Skeld  Kai    Impostor   VIU       30       0      Combustible   -
 *   The Skeld  Lia    Tripulant  VIU       10       20     Cables        -
 *   The Skeld  Max    Tripulant  VIU       20       70     Escut         Cables
 *   The Skeld  Iu     Tripulant  FANTASMA  0        10     Cables        -
 *   The Skeld  Txell  Tripulant  EXPULSAT  50       0      Asteroides    -
 *   Polus      Bru    Impostor   VIU       85       0      -             -
 *   Polus      Pau    Tripulant  VIU       40       30     -             Reactor
 *   Polus      Ona    Tripulant  VIU       85       0      -             -
 *   MIRA HQ    Zoe    Impostor   VIU       10       0      -             -
 *   MIRA HQ    Jan    Tripulant  VIU       60       0      -             -
 *   MIRA HQ    Abril  Tripulant  VIU       20       0      -             -
 *
 * La sospita i l'estat es fixen al final amb setSospita i setEstat (després d'assignar la
 * tasca activa): així les proves de les funcions del DAO no depenen de setTascaActiva.
 */
public final class DadesProva {

	private DadesProva() {
	}

	private static SessionFactory sf() {
		return SessionManager.getSessionFactory();
	}

	/* =====================================================================
	 * reiniciar
	 * ===================================================================== */

	public static void reiniciar() {
		try (Session session = sf().openSession()) {
			Transaction tx = session.beginTransaction();
			try {
				// Esborrat massiu (HQL): primer els personatges (Hibernate buida també la taula de completades)
				session.createMutationQuery("DELETE FROM Personatge").executeUpdate();
				session.createMutationQuery("DELETE FROM Tasca").executeUpdate();
				session.createMutationQuery("DELETE FROM Nau").executeUpdate();
				crear(session);
				tx.commit();
			} catch (RuntimeException e) {
				if (tx.isActive()) {
					tx.rollback();
				}
				throw e;
			}
		}
	}

	/*
	 * Cada entitat es desa (persist) ABANS d'enllaçar-la amb les altres: així ja té id
	 * i els vostres equals/hashCode per id funcionen dins els Set.
	 */
	private static void crear(Session session) {
		Nau skeld = new Nau("The Skeld", 14, true);
		Nau polus = new Nau("Polus", 15, false);
		Nau mira = new Nau("MIRA HQ", 11, true);
		for (Nau n : List.of(skeld, polus, mira)) {
			session.persist(n);
		}

		Tasca cables = new Tasca("Cables", "Electricitat", 30, 10);
		Tasca escut = new Tasca("Escut", "Escuts", 40, 15);
		Tasca combustible = new Tasca("Combustible", "Motors", 20, 5);
		Tasca asteroides = new Tasca("Asteroides", "Armes", 60, 20);
		Tasca reactor = new Tasca("Reactor", "Reactor", 50, 10);
		for (Tasca t : List.of(cables, escut, combustible, asteroides, reactor)) {
			session.persist(t);
		}

		// The Skeld
		Personatge kai = personatge(session, new Impostor("Kai", Color.VERMELL), skeld);
		kai.setTascaActiva(combustible);
		fixar(kai, Estat.VIU, 30, 0);

		Personatge lia = personatge(session, new Tripulant("Lia", Color.BLAU), skeld);
		lia.setTascaActiva(cables);
		fixar(lia, Estat.VIU, 10, 20);

		Personatge max = personatge(session, new Tripulant("Max", Color.VERD), skeld);
		max.afegirTascaCompletada(cables);
		max.setTascaActiva(escut);
		fixar(max, Estat.VIU, 20, 70);

		Personatge iu = personatge(session, new Tripulant("Iu", Color.BLANC), skeld);
		iu.setTascaActiva(cables);
		fixar(iu, Estat.FANTASMA, 0, 10);

		Personatge txell = personatge(session, new Tripulant("Txell", Color.ROSA), skeld);
		txell.setTascaActiva(asteroides);
		fixar(txell, Estat.EXPULSAT, 50, 0);

		// Polus
		fixar(personatge(session, new Impostor("Bru", Color.NEGRE), polus), Estat.VIU, 85, 0);
		Personatge pau = personatge(session, new Tripulant("Pau", Color.GROC), polus);
		pau.afegirTascaCompletada(reactor);
		fixar(pau, Estat.VIU, 40, 30);
		fixar(personatge(session, new Tripulant("Ona", Color.TARONJA), polus), Estat.VIU, 85, 0);

		// MIRA HQ
		fixar(personatge(session, new Impostor("Zoe", Color.BLANC), mira), Estat.VIU, 10, 0);
		fixar(personatge(session, new Tripulant("Jan", Color.VERMELL), mira), Estat.VIU, 60, 0);
		fixar(personatge(session, new Tripulant("Abril", Color.BLAU), mira), Estat.VIU, 20, 0);
		// Els canvis fets després del persist es desen al commit (els objectes són gestionats)
	}

	private static Personatge personatge(Session session, Personatge p, Nau nau) {
		p.setNau(nau);
		session.persist(p);
		return p;
	}

	private static void fixar(Personatge p, Estat estat, double sospita, int punts) {
		p.setEstat(estat);
		p.setSospita(sospita);
		p.setPunts(punts);
	}

	/* =====================================================================
	 * Consultes de comprovació (directes a la BD)
	 * ===================================================================== */

	public static int id(String nom) {
		return valor("SELECT p.id FROM Personatge p WHERE p.nom = :p", nom, Integer.class);
	}

	public static int idNau(String nom) {
		return valor("SELECT n.id FROM Nau n WHERE n.nom = :p", nom, Integer.class);
	}

	public static Estat estat(String nom) {
		return valor("SELECT p.estat FROM Personatge p WHERE p.nom = :p", nom, Estat.class);
	}

	public static double sospita(String nom) {
		return valor("SELECT p.sospita FROM Personatge p WHERE p.nom = :p", nom, Double.class);
	}

	public static int punts(String nom) {
		return valor("SELECT p.punts FROM Personatge p WHERE p.nom = :p", nom, Integer.class);
	}

	// Nom de la tasca activa (null si no en té)
	public static String tascaActiva(String nom) {
		return valor("SELECT t.nom FROM Personatge p LEFT JOIN p.tascaActiva t WHERE p.nom = :p", nom, String.class);
	}

	public static long numCompletades(String nom) {
		return valor("SELECT COUNT(t) FROM Personatge p JOIN p.tasquesCompletades t WHERE p.nom = :p", nom, Long.class);
	}

	public static long numActius(String tasca) {
		return valor("SELECT COUNT(p) FROM Tasca t JOIN t.actius p WHERE t.nom = :p", tasca, Long.class);
	}

	public static long numCompletadors(String tasca) {
		return valor("SELECT COUNT(p) FROM Tasca t JOIN t.completadors p WHERE t.nom = :p", tasca, Long.class);
	}

	public static long numPersonatgesNau(String nau) {
		return valor("SELECT COUNT(p) FROM Nau n JOIN n.personatges p WHERE n.nom = :p", nau, Long.class);
	}

	public static long numPersonatges() {
		try (Session session = sf().openSession()) {
			return session.createQuery("SELECT COUNT(p) FROM Personatge p", Long.class).getSingleResult();
		}
	}

	private static <T> T valor(String hql, String parametre, Class<T> tipus) {
		try (Session session = sf().openSession()) {
			return session.createQuery(hql, tipus).setParameter("p", parametre).getSingleResult();
		}
	}
}
