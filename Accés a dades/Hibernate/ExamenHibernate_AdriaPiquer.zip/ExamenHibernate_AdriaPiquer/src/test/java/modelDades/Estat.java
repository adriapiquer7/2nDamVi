package modelDades;

public enum Estat {
	VIU,
	FANTASMA,
	EXPULSAT
}
