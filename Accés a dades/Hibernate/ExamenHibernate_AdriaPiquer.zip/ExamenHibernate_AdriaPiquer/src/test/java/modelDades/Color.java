package modelDades;

public enum Color {
	VERMELL,
	BLAU,
	VERD,
	GROC,
	ROSA,
	NEGRE,
	BLANC,
	TARONJA
}
