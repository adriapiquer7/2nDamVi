package modelDades;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/*
 * Completa la classe segons l'enunciat: anotacions, constructors, getters, setters
 * (amb els controls que demana l'enunciat), hashCode, equals i toString.
 * NO canvieu els noms ni els tipus dels atributs: el Main i DadesProva els fan servir.
 */
@Entity
@Table(name = "tasca")
public class Tasca {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@NotBlank(message = "El nom és obligatori")
	@Column(name = "nom", nullable = false)
	private String nom;
	@NotBlank(message = "El nom és obligatori")
	@Column(name = "sala", nullable = false)
	private String sala;
	@Min(value = 0, message = "Els punts no poden ser negatius")
	@Column(name = "punts", nullable = false)
	private int punts;
	@DecimalMin(value = "0.0", message = "La valor no pot ser negativa")
	@Column(name = "redusccioSospita", nullable = false)
	private double reduccioSospita;

	@ManyToMany(mappedBy = "PersonatgesAmbTascaActiva", fetch = FetchType.LAZY)
	private Set<Personatge> actius = new HashSet<>();
	@ManyToMany(mappedBy = "tasquesCompletades", fetch = FetchType.LAZY)
	private Set<Personatge> completadors = new HashSet<>();
	
	public Tasca() {
	}

	public Tasca(@NotBlank(message = "El nom és obligatori") String nom,
			@NotBlank(message = "El nom és obligatori") String sala,
			@Min(value = 0, message = "Els punts no poden ser negatius") int punts,
			@DecimalMin(value = "0.0", message = "La valor no pot ser negativa") double reduccioSospita) {
		super();
		this.nom = nom;
		this.sala = sala;
		this.punts = punts;
		this.reduccioSospita = reduccioSospita;
		this.actius = actius;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public String getSala() {
		return sala;
	}

	public void setSala(String sala) {
		this.sala = sala;
	}

	public int getPunts() {
		return punts;
	}

	public void setPunts(int punts) {
		this.punts = punts;
	}

	public double getReduccioSospita() {
		return reduccioSospita;
	}

	public void setReduccioSospita(double reduccioSospita) {
		this.reduccioSospita = reduccioSospita;
	}

	public Set<Personatge> getActius() {
		return actius;
	}

	public void setActius(Set<Personatge> actius) {
		this.actius = actius;
	}

	public Set<Personatge> getCompletadors() {
		return completadors;
	}

	public void setCompletadors(Set<Personatge> completadors) {
		this.completadors = completadors;
	}

	public Integer getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Tasca [id=" + id + ", nom=" + nom + ", sala=" + sala + ", punts=" + punts + ", reduccioSospita="
				+ reduccioSospita + ", actius=" + actius + ", completadors=" + completadors + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Tasca other = (Tasca) obj;
		return Objects.equals(id, other.id);
	}	
}
