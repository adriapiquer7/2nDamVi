package modelDades;

import java.util.HashSet;
import java.util.Objects;
import java.util.Set;

import jakarta.persistence.Column;
import jakarta.persistence.DiscriminatorColumn;
import jakarta.persistence.DiscriminatorType;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Inheritance;
import jakarta.persistence.InheritanceType;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.validation.constraints.DecimalMax;
import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/*
 * Completa la classe segons l'enunciat: anotacions, constructors, getters, setters
 * (amb els controls que demana l'enunciat), hashCode, equals i toString.
 * NO canvieu els noms ni els tipus dels atributs: el Main i DadesProva els fan servir.
 */
@Entity
@Table(name = "personatge")
@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "rol", discriminatorType = DiscriminatorType.STRING, length = 20)
public abstract class Personatge {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@NotBlank(message = "El nom és obligatori")
	@Column(name = "nom", nullable = false, unique = true)
	private String nom;
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "color", nullable = false)
	private Color color;
	@NotNull
	@Enumerated(EnumType.STRING)
	@Column(name = "estat", nullable = false)
	private Estat estat;
	@DecimalMin(value = "0.0", message = "La valor no pot ser negativa")
	@DecimalMax(value = "10.0", message = "La valor no pot superar 10")
	@Column(name = "sospita", nullable = false)
	private double sospita;
	@Min(value = 0, message = "Els punts no poden ser negatius")
	@Column(name = "punts", nullable = false)
	private int punts;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "nau_Actual", nullable = true)
	private Nau nau;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "Tasca_Activa", nullable = true)
	private Tasca tascaActiva;
	@ManyToMany(fetch = FetchType.EAGER)
	@JoinTable(name = "personatge_tasca_completada",
			joinColumns = @JoinColumn(name = "personatge_id"),
			inverseJoinColumns = @JoinColumn(name = "tasca_id"))
	private Set<Tasca> tasquesCompletades = new HashSet<>();
	
	public Personatge() {
	}

	public Personatge(@NotBlank(message = "El nom és obligatori") String nom, @NotNull Color color) {
		super();
		this.nom = nom;
		this.color = color;
		this.sospita = 0;
		this.punts = 0;
		this.estat = estat.VIU;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}

	public Estat getEstat() {
		return estat;
	}

	public void setEstat(Estat estat) {
		this.estat = estat;
	}

	public double getSospita() {
		return sospita;
	}

	public void setSospita(double sospita) {
		this.sospita = sospita;
		if(this.sospita>=100) {
			this.sospita=100;
		}
	}

	public int getPunts() {
		return punts;
	}

	public void setPunts(int punts) {
		this.punts = punts;
	}

	public Nau getNau() {
		return nau;
	}

	public void setNau(Nau nau) {
		this.nau = nau;
	}

	public Tasca getTascaActiva() {
		return tascaActiva;
	}

	public void setTascaActiva(Tasca tascaActiva) {
		this.sospita -= tascaActiva.getReduccioSospita();
		this.tascaActiva = tascaActiva;
	}

	public Set<Tasca> getTasquesCompletades() {
		return tasquesCompletades;
	}

	public Integer getId() {
		return id;
	}

	@Override
	public String toString() {
		return getClass().getSimpleName()+"Personatge [id=" + id + ", nom=" + nom + ", color=" + color + ", estat=" + estat + ", sospita="
				+ sospita + ", punts=" + punts + ", nau=" + nau + ", tascaActiva=" + tascaActiva
				+ ", tasquesCompletades=" + tasquesCompletades + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Personatge other = (Personatge) obj;
		return Objects.equals(id, other.id);
	}

	public void afegirTascaCompletada(Tasca t) {
		//t.setCompletadors(t.getCompletadors().add(this));
	}
	
	
	
	
}
