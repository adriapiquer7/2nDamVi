package modelDades;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/*
 * Subclasse de Personatge segons l'enunciat.
 */
@Entity
@DiscriminatorValue("Impostor")
public class Impostor extends Personatge{

	protected Impostor() {
		
	}

	public Impostor(@NotBlank(message = "El nom és obligatori") String nom, @NotNull Color color) {
		super(nom, color);
	}
	
}
