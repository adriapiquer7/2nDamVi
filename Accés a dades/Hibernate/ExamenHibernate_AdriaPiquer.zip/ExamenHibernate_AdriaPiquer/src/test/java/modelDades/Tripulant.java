package modelDades;

import jakarta.persistence.DiscriminatorValue;
import jakarta.persistence.Entity;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;

/*
 * Subclasse de Personatge segons l'enunciat.
 */
@Entity
@DiscriminatorValue("Tripulant")
public class Tripulant extends Personatge{

	protected Tripulant() {
	}

	public Tripulant(@NotBlank(message = "El nom és obligatori") String nom, @NotNull Color color) {
		super(nom, color);
	}
}
