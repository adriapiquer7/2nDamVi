package modelDades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;

/*
 * Completa la classe segons l'enunciat: anotacions, constructors, getters, setters
 * (amb els controls que demana l'enunciat), hashCode, equals i toString.
 * NO canvieu els noms ni els tipus dels atributs: el Main i DadesProva els fan servir.
 */
@Entity
@Table(name = "nau")
public class Nau {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id")
	private Integer id;
	@NotBlank(message = "El nom és obligatori")
	@Column(name = "nom", nullable = false)
	private String nom;
	@Min(value = 0, message = "Els punts no poden ser negatius")
	@Column(name = "numSales", nullable = false)
	private int numSales;
	@Column(name = "ventilacions")
	private boolean ventilacions;

	@OneToMany(mappedBy = "PersonatgesNau", fetch = FetchType.LAZY)
	private List<Personatge> personatges = new ArrayList<>();

	public Nau() {
	}

	public Nau(@NotBlank(message = "El nom és obligatori") String nom,
			@Min(value = 0, message = "Els punts no poden ser negatius") int numSales, boolean ventilacions) {
		this.nom = nom;
		this.numSales = numSales;
		this.ventilacions = ventilacions;
	}

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public int getNumSales() {
		return numSales;
	}

	public void setNumSales(int numSales) {
		this.numSales = numSales;
	}

	public boolean isVentilacions() {
		return ventilacions;
	}

	public void setVentilacions(boolean ventilacions) {
		this.ventilacions = ventilacions;
	}

	public List<Personatge> getPersonatges() {
		return personatges;
	}

	public void setPersonatges(List<Personatge> personatges) {
		this.personatges = personatges;
	}

	public Integer getId() {
		return id;
	}

	@Override
	public String toString() {
		return "Nau [id=" + id + ", nom=" + nom + ", numSales=" + numSales + ", ventilacions=" + ventilacions
				+ ", personatges=" + personatges + "]";
	}

	@Override
	public int hashCode() {
		return Objects.hash(id);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Nau other = (Nau) obj;
		return Objects.equals(id, other.id);
	}
	
}
