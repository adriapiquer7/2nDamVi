package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service.ObjecteService;

@RestController
@RequestMapping("/rpg/objecte")
public class ObjecteController {
    @Autowired
    private ObjecteService service;
    
    @PostMapping(path="add/nom/{nom}/codi/{codi}/preu/{preu}/nivellMin/{nivellMin}/classe/{classe}")
    ResponseEntity<String> afegirObjecte(@RequestParam String nom,@RequestParam String codi,@RequestParam int preu,
    		@RequestParam int nivellMin, @RequestParam String classe){
    	return service.afegirObjecte(nom, codi, preu, nivellMin, classe);
    }
}
