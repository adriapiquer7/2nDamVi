package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Gremi;

public interface GremiRepository extends JpaRepository<Gremi, Integer>{

}
