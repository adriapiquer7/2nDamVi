package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service.GremiService;

@RestController
@RequestMapping("/rpg/gremi")
public class GremiController {

    @Autowired
    private GremiService service;
    
    @PostMapping(path="add/nom/{nom}/capacitat/{capacitat}")
    ResponseEntity<String> afegirGremi(@RequestParam String nom,@RequestParam int capacitat){
    	return service.afegirGremi(nom, capacitat);
    }
}
