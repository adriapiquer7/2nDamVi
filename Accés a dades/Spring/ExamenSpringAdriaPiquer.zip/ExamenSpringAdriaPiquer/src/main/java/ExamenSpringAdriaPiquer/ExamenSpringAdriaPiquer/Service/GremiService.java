package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Gremi;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.GremiRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.HeroiRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.ObjecteRepository;


@Service
public class GremiService {
    @Autowired
    private GremiRepository repository;
    @Autowired
    private ObjecteRepository oRepo;
    @Autowired
    private HeroiRepository hRepo;
	public ResponseEntity<String> afegirGremi(String nom, int capacitat) {
		if(capacitat>=1) {
			Gremi g = repository.save(new Gremi(nom, capacitat));
			return ResponseEntity.status(HttpStatus.CREATED)
						.header("Gremi-info", "INSERIT GREMI ID "+g.getId())
						.body("GREMI INSERIT "+g); 
		}
		else {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
						.header("Gremi-info", "CAPACITAT NO VALIDA")
						.body("ERROR CAPACITAT "+capacitat+" NO VALIDA");
		}		    
	}
}
