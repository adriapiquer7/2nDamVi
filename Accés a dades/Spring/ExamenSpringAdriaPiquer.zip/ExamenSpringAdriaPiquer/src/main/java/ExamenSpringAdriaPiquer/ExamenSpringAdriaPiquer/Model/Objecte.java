package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToMany;

@Entity
public class Objecte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false, unique = true)
    private String codi;

    @Column(nullable = false)
    private int preu;

    @Column(nullable = false)
    private int nivellMinim;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Classe classe;

    @ManyToMany(mappedBy = "objectes")
    private List<Heroi> herois = new ArrayList<>();

    public Objecte() {}

    public Objecte(String nom, String codi, int preu, int nivellMinim, Classe classe) {
        this.nom = nom;
        this.codi = codi;
        this.preu = preu;
        this.nivellMinim = nivellMinim;
        this.classe = classe;
    }

    public void addHeroi(Heroi heroi) { this.herois.add(heroi); }
    public void removeHeroi(Heroi heroi) { this.herois.remove(heroi); }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public String getCodi() { return codi; }
    public void setCodi(String codi) { this.codi = codi; }
    public int getPreu() { return preu; }
    public void setPreu(int preu) { this.preu = preu; }
    public int getNivellMinim() { return nivellMinim; }
    public void setNivellMinim(int nivellMinim) { this.nivellMinim = nivellMinim; }
    public Classe getClasse() { return classe; }
    public void setClasse(Classe classe) { this.classe = classe; }
    public List<Heroi> getHerois() { return herois; }
    public void setHerois(List<Heroi> herois) { this.herois = herois; }

    @Override
    public String toString() {
        return "Objecte [id=" + id + ", nom=" + nom + ", codi=" + codi + ", preu=" + preu +
               ", nivellMinim=" + nivellMinim + ", classe=" + classe + "]";
    }

    @Override
    public int hashCode() { return Objects.hash(id); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        return id == ((Objecte) obj).id;
    }
}
