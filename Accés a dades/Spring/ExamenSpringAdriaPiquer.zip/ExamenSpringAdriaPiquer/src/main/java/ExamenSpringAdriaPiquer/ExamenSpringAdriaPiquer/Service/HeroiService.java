package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Classe;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Heroi;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Objecte;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.HeroiRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.ObjecteRepository;

@Service
public class HeroiService {
	@Autowired
	private HeroiRepository repository;
	@Autowired
	private ObjecteRepository oRepo;
	

	public ResponseEntity<String> afegirHeroi(String nom, String classe, int nivell, int monedes) {
		Classe c;
		try {
			c = Classe.valueOf(classe);
		}catch(Exception e){
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.header("Heroi-info", "CLASSE NO EXISTEIX")
					.body("ERROR CLASSE "+classe+" NO EXISTEIX");
		}
		Heroi h = repository.save(new Heroi(nom,c, nivell, monedes));
		return ResponseEntity.status(HttpStatus.CREATED)
				.header("Heroi-info","Inserit heroi ID: "+h.getId())
				.body("HEROI INSERIT "+h);
	}


	public ResponseEntity<Heroi> comprarObjecte(int idHeroi, String codi) {
		Optional<Heroi> opHeroi = repository.findById(idHeroi);
		if(!opHeroi.isPresent()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.header("Heroi-info", "NO EXISTEIX HEROI"+idHeroi)
					.body(null);
		}
		Optional<Objecte> opObj = oRepo.findByCodi(codi);
		if(!opObj.isPresent()) {
			return ResponseEntity.status(HttpStatus.NOT_FOUND)
					.header("Heroi-info", "NO EXISTEIX OBJECTE"+codi)
					.body(null);
		}
		Heroi h = opHeroi.get();
		List<Objecte> objectes = h.getObjectes();
		for(Objecte o:objectes) {
			if(o.getCodi().equals(codi)) {
				return ResponseEntity.status(HttpStatus.CONFLICT)
						.header("Heroi-info", "HEROI"+idHeroi+"JA TE"+codi)
						.body(null);
			}
		}
		if(h.getClass().equals(opObj.get().getClass())) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.header("Heroi-info", "OBJECTE NOMES PER A"+opObj.get().getClass())
					.body(null);
		}
		if(h.getNivell()<opObj.get().getNivellMinim()) {
			return ResponseEntity.status(HttpStatus.FORBIDDEN)
					.header("Heroi-info", "CAL NIVELL"+opObj.get().getNivellMinim())
					.body(null);
		}
		if(h.getMonedes()<opObj.get().getPreu()) {
			return ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED)
					.header("Heroi-info", "FALTEN"+(opObj.get().getPreu()-h.getMonedes())+"MONEDES")
					.body(null);
		}
		Objecte objecte = opObj.get(); 
		h.setMonedes(h.getMonedes()-opObj.get().getPreu());
		h.addObjecte(objecte);
		return ResponseEntity.status(HttpStatus.OK)
				.header("Heroi-info", "HEROI"+idHeroi+" HA COMPRAT"+codi)
				.body(h);
		
	}
}
