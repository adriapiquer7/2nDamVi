package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Heroi;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service.HeroiService;

@RestController
@RequestMapping("/rpg/heroi")
public class HeroiController {

	@Autowired
    private HeroiService service;
	
    @PostMapping("add/nom/{nom}/classe/{classe}/nivell/{nivell}/monedes/{monedes}")
    ResponseEntity<String> afegirNau(@RequestParam String nom, @RequestParam String classe,@RequestParam int nivell,@RequestParam int monedes) {
        return service.afegirHeroi(nom,classe, nivell, monedes);
    }
    
    @PostMapping("comprar/idHeroi/{idHeroi}/coi/{codi}")
    ResponseEntity<Heroi> comprarObjecte(@RequestParam int idHeroi, @RequestParam String codi) {
        return service.comprarObjecte(idHeroi, codi);
    }
}
