package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Classe;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Heroi;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Objecte;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.GremiRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.HeroiRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository.ObjecteRepository;

@Service
public class ObjecteService {
    @Autowired
    private ObjecteRepository repository;
    @Autowired
    private GremiRepository gRepo;
    @Autowired
    private HeroiRepository hRepo;
    
	public ResponseEntity<String> afegirObjecte(String nom, String codi, int preu, int nivellMinim, String classe) {
		Classe c;
		try {
			c = Classe.valueOf(classe);
		}catch(Exception e){
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.header("Objecte-info", "CLASSE NO EXISTEIX")
					.body("ERROR CLASSE "+classe+" NO EXISTEIX");
		}
		Optional<Objecte> opObj = repository.findByCodi(codi);
		if(opObj.isPresent()) {
			return ResponseEntity.status(HttpStatus.CONFLICT)
					.header("Objecte-info", "CODI JA EXISTEIX")
					.body("ERROR: CODI"+codi+"JA EXISTEIX");
		}
		
		Objecte obj = repository.save(new Objecte(nom,codi, preu, nivellMinim, c));
		return ResponseEntity.status(HttpStatus.CREATED)
				.header("Objecte-info","Inserit Objecte ID: "+obj.getId())
				.body("Objecte INSERIT "+obj);
	}
}
