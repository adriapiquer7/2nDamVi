package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Gremi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private String nom;

    @Column(nullable = false)
    private int capacitatMaxima;

    @OneToMany(mappedBy = "gremi")
    private List<Heroi> herois = new ArrayList<>();

    public Gremi() {}

    public Gremi(String nom, int capacitatMaxima) {
        this.nom = nom;
        this.capacitatMaxima = capacitatMaxima;
    }

    public void addHeroi(Heroi heroi) {
        this.herois.add(heroi);
        heroi.setGremi(this);
    }

    public void removeHeroi(Heroi heroi) {
        this.herois.remove(heroi);
        heroi.setGremi(null);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public int getCapacitatMaxima() { return capacitatMaxima; }
    public void setCapacitatMaxima(int capacitatMaxima) { this.capacitatMaxima = capacitatMaxima; }
    public List<Heroi> getHerois() { return herois; }
    public void setHerois(List<Heroi> herois) { this.herois = herois; }

    @Override
    public String toString() {
        return "Gremi [id=" + id + ", nom=" + nom + ", capacitatMaxima=" + capacitatMaxima + "]";
    }

    @Override
    public int hashCode() { return Objects.hash(id); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        return id == ((Gremi) obj).id;
    }
}
