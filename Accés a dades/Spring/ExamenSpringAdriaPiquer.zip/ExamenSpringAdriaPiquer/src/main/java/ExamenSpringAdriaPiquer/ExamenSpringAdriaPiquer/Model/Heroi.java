package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;
import jakarta.persistence.ManyToOne;

@Entity
public class Heroi {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(nullable = false)
    private String nom;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private Classe classe;

    @Column(nullable = false)
    private int nivell;

    @Column(nullable = false)
    private int monedes;

    @ManyToOne
    @JoinColumn(name = "gremi_id")
    private Gremi gremi;

    @ManyToMany
    @JoinTable(
        name = "heroi_objecte",
        joinColumns = @JoinColumn(name = "heroi_id"),
        inverseJoinColumns = @JoinColumn(name = "objecte_id")
    )
    private List<Objecte> objectes = new ArrayList<>();

    public Heroi() {}

    public Heroi(String nom, Classe classe, int nivell, int monedes) {
        this.nom = nom;
        this.classe = classe;
        this.nivell = nivell;
        this.monedes = monedes;
    }

    public void addObjecte(Objecte objecte) {
        this.objectes.add(objecte);
        objecte.addHeroi(this);
    }

    public void removeObjecte(Objecte objecte) {
        this.objectes.remove(objecte);
        objecte.removeHeroi(this);
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNom() { return nom; }
    public void setNom(String nom) { this.nom = nom; }
    public Classe getClasse() { return classe; }
    public void setClasse(Classe classe) { this.classe = classe; }
    public int getNivell() { return nivell; }
    public void setNivell(int nivell) { this.nivell = nivell; }
    public int getMonedes() { return monedes; }
    public void setMonedes(int monedes) { this.monedes = monedes; }
    public Gremi getGremi() { return gremi; }
    public void setGremi(Gremi gremi) { this.gremi = gremi; }
    public List<Objecte> getObjectes() { return objectes; }
    public void setObjectes(List<Objecte> objectes) { this.objectes = objectes; }

    @Override
    public String toString() {
        return "Heroi [id=" + id + ", nom=" + nom + ", classe=" + classe +
               ", nivell=" + nivell + ", monedes=" + monedes + "]";
    }

    @Override
    public int hashCode() { return Objects.hash(id); }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        return id == ((Heroi) obj).id;
    }
}
