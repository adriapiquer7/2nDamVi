package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Classe;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Heroi;

public interface HeroiRepository extends JpaRepository<Heroi, Integer> {

	Heroi findFirstByClasse(Classe classe);
}
