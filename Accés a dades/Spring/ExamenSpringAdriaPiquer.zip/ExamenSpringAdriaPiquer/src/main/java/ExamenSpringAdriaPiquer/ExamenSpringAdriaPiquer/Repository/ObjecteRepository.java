package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model.Objecte;

public interface ObjecteRepository extends JpaRepository<Objecte, Integer>{
	Optional<Objecte> findByCodi(String Codi);
}
