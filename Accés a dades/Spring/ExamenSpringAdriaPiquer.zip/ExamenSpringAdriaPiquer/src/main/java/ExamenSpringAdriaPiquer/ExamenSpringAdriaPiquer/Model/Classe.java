package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer.Model;

public enum Classe {
    GUERRER, MAG, ARQUER, LLADRE
}
