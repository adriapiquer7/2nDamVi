package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ExamenSpringAdriaPiquerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ExamenSpringAdriaPiquerApplication.class, args);
	}

}
