package ExamenSpringAdriaPiquer.ExamenSpringAdriaPiquer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamenSpringAdriaPiquerApplicationTests {

	@Test
	void contextLoads() {
	}

}
