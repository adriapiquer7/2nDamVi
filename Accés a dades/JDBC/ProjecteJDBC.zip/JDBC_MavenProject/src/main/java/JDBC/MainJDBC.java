package JDBC;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class MainJDBC {

	static Scanner sc = new Scanner(System.in);
	public static void main(String[] args) {

		JDBCSmartCity.conectar();
		
		//int files =JDBCSmartCity.registraLectura(sc.nextLine(), sc.nextDouble());
		//System.out.println(files);
		//JDBCSmartCity.fitxaSensor(sc.nextInt());
		//int files = JDBCSmartCity.marcaDubtoses(sc.nextInt(), sc.nextDouble(), sc.nextDouble());
		//System.out.println(files);
		//String fechaTexto = sc.nextLine();
		//LocalDate fecha = LocalDate.parse(fechaTexto);
		//int files = JDBCSmartCity.desactivaSensorsSilenciosos(fecha);
		//int files = JDBCSmartCity.netejaLecturesError(fecha);
		//System.out.println(files);
		//int files =  JDBCSmartCity.eliminaZonesBuides();
		//System.out.println(files);
		//JDBCSmartCity.sensorsSenseLectures();
		//JDBCSmartCity.lecturesDeZona(sc.nextLine(), sc.nextLine());
		//JDBCSmartCity.resumZones();
		//JDBCSmartCity.estadistiquesPerTipus();
		//JDBCSmartCity.creacioTaulaManteniments();
		//int files = JDBCSmartCity.inertsManteniments();
		//System.out.println(files);
		//JDBCSmartCity.alterTableSensors();
		//JDBCSmartCity.insertDuplicat();
		//JDBCSmartCity.cercaSensors(null, null, null);
		//System.out.println("------------------------------------------");
		//JDBCSmartCity.cercaSensors("Temperatura", null, true);
		//System.out.println("------------------------------------------");
		//JDBCSmartCity.cercaSensors(null, 2, false);
		//JDBCSmartCity.lecturesEntreDates(3, LocalDateTime.of(2020,1,1,0,0), LocalDateTime.of(2026,9,21,13,36));
		
	}

}
