package JDBC;

import java.sql.Timestamp;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Scanner;

public class JDBCSmartCity {

	// Dades de la connexió
    private static String url = "jdbc:mysql://localhost:3306/ciutat_sensors";
    private static String user = "root";
    private static String password = "root";
	static Scanner sc = new Scanner(System.in);
    
	public static void conectar() {
		
     // Intentar establir connexió
        try {
            // Carregar el driver
            Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
         // Crear un Statement per executar la consulta SQL
            Statement statement = connection.createStatement();

            // Executar la comanda SHOW DATABASES
            String query = "SHOW DATABASES";
            ResultSet resultSet = statement.executeQuery(query);

            // Mostrar les bases de dades
            System.out.println("Llistat de bases de dades:");
            while (resultSet.next()) {
                System.out.println(resultSet.getString(1)); // Mostrar el nombre de la base de dades
            }

            // Tancar ResultSet, Statement i la connexió
            resultSet.close();
            statement.close();
            connection.close();
            
        } catch (ClassNotFoundException e) {
            System.out.println("No s'ha pogut carregar el driver JDBC");
            e.printStackTrace();
        } catch (SQLException e) {
            System.out.println("Error al connectar amb la base de dades");
            e.printStackTrace();
        }
	}
	public static int registraLectura(String nomSensor, double valor){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String querycheck = "SELECT id, actiu FROM sensors  WHERE nom = ?";
            
            PreparedStatement psCheck = connection.prepareStatement(querycheck);
            psCheck.setString(1, nomSensor);
            
            ResultSet rsCheck = psCheck.executeQuery();

            if (!rsCheck.next() || rsCheck.getInt("actiu")==0) {
            	System.out.println("El sensor "+ nomSensor + " no exixsteix o no esta actiu");
            	return -1;
            }
            int idSensor = rsCheck.getInt("id");

            String insertQuery = "INSERT INTO ciutat_sensors.lectures\r\n"
            		+ " (sensor_id, valor, data_lectura, qualitat)\r\n"
            		+ " VALUES(?, ?, NOW(), 'OK');";
            
            PreparedStatement psInsert = connection.prepareStatement(insertQuery);
            psInsert.setInt(1, idSensor);
            psInsert.setDouble(2, valor);
            int files = psInsert.executeUpdate();
            
           rsCheck.close();
           psInsert.close();
           return files;
            
            
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public static void fitxaSensor(int idSensor){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String SelectQuery = "SELECT s.nom, ts.nom AS nom_tipus_sensor, z.nom AS nom_zona, s.actiu, (SELECT COUNT(*) FROM lectures l WHERE l.sensor_id  = ?) AS total_lectures, (SELECT l2.valor FROM lectures l2 WHERE l2.sensor_id = ? ORDER BY data_lectura DESC LIMIT 1) AS valor_ultima_lectura, (SELECT l3.data_lectura FROM lectures l3 WHERE l3.sensor_id = ? ORDER BY data_lectura DESC LIMIT 1) AS data_ultima_lectura\r\n"
            		+ "FROM sensors s \r\n"
            		+ "JOIN tipus_sensors ts ON s.tipus_sensor_id = ts.id \r\n"
            		+ "JOIN zones z ON z.id = s.zona_id  \r\n"
            		+ "WHERE s.id = ?;";
            // he fet nomes una consulta amb 3 subconsultes per les dades de les 2 taules que hi ha amb els joins
            PreparedStatement psSelect = connection.prepareStatement(SelectQuery);
            psSelect.setInt(1, idSensor);
            psSelect.setInt(2, idSensor);
            psSelect.setInt(3, idSensor);
            psSelect.setInt(4, idSensor);
            
            ResultSet rsSelect = psSelect.executeQuery();
            rsSelect.next();
            String nomSensor = rsSelect.getString("nom");
            String nomTipusSensor = rsSelect.getString("nom_tipus_sensor");
            String nomZona = rsSelect.getString("nom_zona");
            int actiu = rsSelect.getInt("actiu");
            int totalLectures = rsSelect.getInt("total_lectures");
            double valorUltimaLectura = rsSelect.getDouble("valor_ultima_lectura");
            String dataUltimaLectura = rsSelect.getString("data_ultima_lectura");
            
            System.out.println("Nom: "+nomSensor+", Nom Tipus Sensor: "+nomTipusSensor+", Nom Zona: "+nomZona+", Actiu: "+actiu+", Total Lectures: "+totalLectures+", Valor Ultima Lectura: "+valorUltimaLectura+", Data Ultima Lectura: "+dataUltimaLectura);

            rsSelect.close();
            psSelect.close();
            
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static int marcaDubtoses(int idSensor, double min, double max) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String updateQuery = "UPDATE lectures"
            		+ " SET qualitat = 'DUBTOSA'"
            		+ " WHERE sensor_id = ?"
            		+ " AND (valor > ? OR valor < ?)"
            		+ " AND qualitat <> 'DUBTOSA'"
            		+ " AND qualitat <> 'ERROR';";
            

            PreparedStatement psUpdate = connection.prepareStatement(updateQuery);
            psUpdate.setInt(1, idSensor);
            psUpdate.setDouble(2, max);
            psUpdate.setDouble(3, min);
            
            int files = psUpdate.executeUpdate();
            
            psUpdate.close();
            
            return files;
            
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public static int desactivaSensorsSilenciosos(LocalDate data) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String updateQuery = "UPDATE ciutat_sensors.sensors s"
                    + " LEFT JOIN lectures l ON l.sensor_id = s.id"
                    + " AND l.data_lectura >= ?"
                    + " SET s.actiu=0"
                    + " WHERE s.actiu=1 AND l.sensor_id IS NULL;";
            
            PreparedStatement psUpdate = connection.prepareStatement(updateQuery);
            psUpdate.setDate(1, Date.valueOf(data));
            
            int files = psUpdate.executeUpdate();
            psUpdate.close();
            return files;
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public static int netejaLecturesError(LocalDate data){
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String deleteQuery = "DELETE FROM lectures"
            		+ " WHERE qualitat = 'ERROR' AND data_lectura <= ?;";
            
            PreparedStatement psDelete = connection.prepareStatement(deleteQuery);
            psDelete.setDate(1, Date.valueOf(data));
            
            int files =psDelete.executeUpdate();
            psDelete.close();
            return files;
            
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public static int eliminaZonesBuides() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String deleteQuery = "DELETE FROM zones\r\n"
            		+ "WHERE id IN (\r\n"
            		+ "    SELECT id\r\n"
            		+ "    FROM (\r\n"
            		+ "        SELECT z.id\r\n"
            		+ "        FROM zones z\r\n"
            		+ "        LEFT JOIN sensors s ON s.zona_id = z.id\r\n"
            		+ "        WHERE s.id IS NULL\r\n"
            		+ "    ) AS zonas_sin_sensores\r\n"
            		+ ")";
            
            PreparedStatement psDelete = connection.prepareStatement(deleteQuery);
            int files = psDelete.executeUpdate();
            psDelete.close();
            return files;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return -1;
	}
	public static void sensorsSenseLectures() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String selectQuery = "SELECT s.nom nomSensor, z.nom nomZona, ts.nom nomTipusSensor\r\n"
            		+ " FROM sensors s \r\n"
            		+ " JOIN zones z ON s.zona_id = z.id\r\n"
            		+ " JOIN tipus_sensors ts ON s.tipus_sensor_id = ts.id\r\n"
            		+ " LEFT JOIN lectures l ON l.sensor_id = s.id \r\n"
            		+ " WHERE l.id IS NULL\r\n"
            		+ " ORDER BY nomzona , nomsensor";
            
            PreparedStatement psSelect = connection.prepareStatement(selectQuery);
            ResultSet rsSelect = psSelect.executeQuery();
            
            while(rsSelect.next()) {
            	String nomSensor = rsSelect.getString("nomSensor");
            	String nomZona = rsSelect.getString("nomZona");
            	String nomTipusSensor = rsSelect.getString("nomTipusSensor");
            	System.out.println("Nom: "+ nomSensor+", Zona: "+nomZona+", Tipus: "+nomTipusSensor);
            }
            
            rsSelect.close();
            psSelect.close();
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void lecturesDeZona(String nomZona, String qualitat) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String selectQuery = "SELECT s.nom nomSensor, ts.nom nomTipusSensor, l.valor valor, l.data_lectura dataLectura \r\n"
            		+ " FROM lectures l \r\n"
            		+ " JOIN sensors s ON l.sensor_id = s.id\r\n"
            		+ " JOIN zones z ON s.zona_id = z.id\r\n"
            		+ " JOIN tipus_sensors ts ON ts.id = s.tipus_sensor_id\r\n"
            		+ " WHERE z.nom = ? AND l.qualitat = ?\r\n"
            		+ " ORDER BY dataLectura DESC;";
            
            PreparedStatement psSelect = connection.prepareStatement(selectQuery);
            psSelect.setString(1, nomZona);
            psSelect.setString(2, qualitat);
            
            ResultSet rsSelect = psSelect.executeQuery();
            
            while(rsSelect.next()) {
            	String zonaNom = rsSelect.getString("nomSensor");
            	String nomTipusSensor = rsSelect.getString("nomTipusSensor");
            	Double valor = rsSelect.getDouble("valor");
            	Timestamp dataLectura = rsSelect.getTimestamp("dataLectura");
            	System.out.println("Nom: "+zonaNom+", Tipus: "+nomTipusSensor+", Valor: "+valor+", Data lectura: "+dataLectura);
            }
            rsSelect.close();
            psSelect.close();
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void resumZones() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String selectQuery = "SELECT z.nom AS nomZona, COUNT(s.id) AS nombreSensors, SUM(s.actiu) AS sensorsActius\r\n"
            		+ " FROM zones z\r\n"
            		+ " LEFT JOIN sensors s ON s.zona_id = z.id\r\n"
            		+ " GROUP BY z.id, z.nom\r\n"
            		+ " ORDER BY nombreSensors DESC;";
            PreparedStatement psSelect = connection.prepareStatement(selectQuery);
            
           ResultSet rsSelect = psSelect.executeQuery();
           
           while(rsSelect.next()) {
        	   String nomZona = rsSelect.getString("nomZona");
        	   int nombreSensors = rsSelect.getInt("nombreSensors");
        	   int sensorsActius = rsSelect.getInt("sensorsActius");
        	   System.out.println("Nom zona: "+nomZona+", Nombre Sensors: "+nombreSensors+", Sensors Actius: "+sensorsActius);
           }
           rsSelect.close();
           psSelect.close();
           
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void estadistiquesPerTipus() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String selectQuery = "SELECT ts.nom AS nomTipusSensor, MIN(l.valor) AS valorMinim, MAX(l.valor) AS valorMaxim, ROUND(AVG(l.valor), 1) AS valorMitja\r\n"
            		+ "FROM tipus_sensors ts\r\n"
            		+ "JOIN sensors s ON s.tipus_sensor_id = ts.id\r\n"
            		+ "JOIN lectures l ON l.sensor_id = s.id\r\n"
            		+ "WHERE l.qualitat = 'OK'\r\n"
            		+ "GROUP BY ts.id, ts.nom\r\n"
            		+ "HAVING COUNT(l.id) >= 2\r\n"
            		+ "ORDER BY valorMitja DESC;";
            
            PreparedStatement psSelect = connection.prepareStatement(selectQuery);
            
            ResultSet rsSelect = psSelect.executeQuery();
            
            while(rsSelect.next()) {
            	String nomTipusSensor = rsSelect.getString("nomTipusSensor");
            	Double valorMinim = rsSelect.getDouble("valorMinim");
            	Double valorMaxim = rsSelect.getDouble("valorMaxim");
            	Double valorMitja = rsSelect.getDouble("valorMitja");
            	
            	System.out.println("Nom Tipus Sensor: "+nomTipusSensor+", Valor Minim: "+valorMinim+", Valor Maxim: "+valorMaxim+", Valor Mitja: "+valorMitja);
            }
            rsSelect.close();
            psSelect.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void creacioTaulaManteniments() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String createTableQuery="CREATE TABLE manteniments (\r\n"
            		+ "    id INT AUTO_INCREMENT PRIMARY KEY,\r\n"
            		+ "    sensor_id INT,\r\n"
            		+ "    data_intervencio DATE,\r\n"
            		+ "    tecnic VARCHAR(100),\r\n"
            		+ "    tipus ENUM('PREVENTIU', 'CORRECTIU'),\r\n"
            		+ "    cost DECIMAL(8,2),\r\n"
            		+ "    descripcio VARCHAR(255),\r\n"
            		+ "    FOREIGN KEY (sensor_id) REFERENCES sensors(id)\r\n"
            		+ ");";
            
            PreparedStatement psCreateTable = connection.prepareStatement(createTableQuery);
            psCreateTable.executeUpdate();
            psCreateTable.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static int inertsManteniments() {
        int files = 0;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String insertQuery = "INSERT INTO ciutat_sensors.manteniments\r\n"
            		+ "(sensor_id, data_intervencio, tecnic, tipus, cost, descripcio)\r\n"
            		+ "VALUES(?, ?, ?, ?, ?, ?);";
            PreparedStatement psInsert = connection.prepareStatement(insertQuery);
            for (int i = 0; i < 3; i++) {
				psInsert.setInt(1, sc.nextInt());
				sc.nextLine();
				psInsert.setDate(2, Date.valueOf(sc.nextLine()));
				psInsert.setString(3, sc.nextLine());
				psInsert.setString(4, sc.nextLine());
				psInsert.setDouble(5, sc.nextDouble());
				sc.nextLine();
				psInsert.setString(6, sc.nextLine());
				
				files += psInsert.executeUpdate();
			}
            psInsert.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return files;
	}
	public static void alterTableSensors() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String alterTableQuery = "ALTER TABLE ciutat_sensors.sensors \r\n"
            		+ "ADD COLUMN ultim_manteniment DATE NULL, \r\n"
            		+ "ADD CONSTRAINT unique_nom_sensor UNIQUE (nom);";
            
            PreparedStatement psAlterTable = connection.prepareStatement(alterTableQuery);
            
            psAlterTable.executeUpdate();
            System.out.println("OK");
            
            psAlterTable.close();
            
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
	public static void insertDuplicat() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String insertQuery = "INSERT INTO ciutat_sensors.sensors\r\n"
            		+ "(nom, zona_id, tipus_sensor_id, pos_x, pos_y, altura, orientacio, actiu, data_instalacio, ultim_manteniment)\r\n"
            		+ "VALUES('TEMP-CENTRE-01', ?, ?, ?, ?, ?, ?, ?, ?, ?);";
            
            PreparedStatement psInsert = connection.prepareStatement(insertQuery);
            psInsert.setInt(1, sc.nextInt());
            psInsert.setInt(2, sc.nextInt());
            psInsert.setDouble(3, sc.nextDouble());
            psInsert.setDouble(4, sc.nextDouble());
            psInsert.setDouble(5, sc.nextDouble());
            psInsert.setInt(6, sc.nextInt());
            psInsert.setInt(7, sc.nextInt());
            sc.nextLine();
            psInsert.setDate(8, Date.valueOf(sc.nextLine()));
            psInsert.setDate(9, Date.valueOf(sc.nextLine()));
            psInsert.executeUpdate();
            psInsert.close();

		} catch (SQLIntegrityConstraintViolationException e) {
			System.out.println("ERROR: Insert amb nom duplicat");
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void cercaSensors(String text, Integer idTipus, Boolean nomesActius) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
            // Establir connexió
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connexió exitosa!");
            
            String selectQuery = "SELECT s.id, s.nom, z.nom AS nomZona, ts.nom AS nomTipusSensor, s.actiu \r\n"
            		+ "FROM sensors s \r\n"
            		+ "JOIN zones z ON s.zona_id = z.id \r\n"
            		+ "JOIN tipus_sensors ts ON s.tipus_sensor_id = ts.id\r\n"
            		+ "WHERE 1=1";

            if (text != null) {
                selectQuery += " AND s.nom LIKE ?";
            }
            if (idTipus != null) {
                selectQuery += " AND s.tipus_sensor_id = ?";
            }
            if (nomesActius != null && nomesActius) {
                selectQuery += " AND s.actiu = 1";
            }
            
            PreparedStatement psSelect = connection.prepareStatement(selectQuery);
            
            int parametre = 1;

            if (text != null) {
                psSelect.setString(parametre++, "%" + text + "%");
            }

            if (idTipus != null) {
                psSelect.setInt(parametre++, idTipus);
            }
            
            ResultSet rsSelect = psSelect.executeQuery();
            
            while(rsSelect.next()) {
            	
            	int id = rsSelect.getInt("id");
                String nom = rsSelect.getString("nom");
                String nomZona = rsSelect.getString("nomZona");
                String nomTipusSensor = rsSelect.getString("nomTipusSensor");
                boolean actiu = rsSelect.getBoolean("actiu");
                System.out.println("Id: "+id+", Nom: "+nom+", Nom Zona: "+nomZona+", Nom Tipus Sensor: "+nomTipusSensor+", Actiu: "+actiu);
            }
            rsSelect.close();
            psSelect.close();
            
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	public static void lecturesEntreDates(int idSensor, LocalDateTime inici, LocalDateTime fi) {
	    try {
	        Class.forName("com.mysql.cj.jdbc.Driver");
	        // Establir connexió
	        Connection connection = DriverManager.getConnection(url, user, password);
	        System.out.println("Connexió exitosa!");

	        String selectQuery = "SELECT l.id, l.valor, l.data_lectura, l.qualitat \r\n"
	        		+ "FROM lectures l\r\n"
	        		+ "WHERE l.sensor_id = ? \r\n"
	        		+ "AND l.data_lectura BETWEEN ? AND ? \r\n"
	        		+ "ORDER BY l.data_lectura;";

	        PreparedStatement psSelect = connection.prepareStatement(selectQuery);

	        psSelect.setInt(1, idSensor);
	        psSelect.setTimestamp(2, Timestamp.valueOf(inici));
	        psSelect.setTimestamp(3, Timestamp.valueOf(fi));

	        ResultSet rsSelect = psSelect.executeQuery();

	        int ok = 0;
	        int error = 0;

	        while (rsSelect.next()) {
	            int id = rsSelect.getInt("id");
	            double valor = rsSelect.getDouble("valor");
	            Timestamp dataLectura = rsSelect.getTimestamp("data_lectura");
	            String qualitat = rsSelect.getString("qualitat");

	            System.out.println("Id: "+id+", Valor: "+valor+", Data Lectura: "+dataLectura+", Qualitat: "+qualitat);

	            if (qualitat.equals("OK")) {
	                ok++;
	            } else if (qualitat.equals("ERROR")) {
	                error++;
	            }
	        }

	        System.out.println("Lectures OK: " + ok);
	        System.out.println("Lectures ERROR: " + error);

	        rsSelect.close();
	        psSelect.close();

	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	}
}